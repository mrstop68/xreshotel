<script type="module" src="https://widget.resclick.com/rc-widget.min.js"></script>
<!-- Booking Widget -->
<rc-widget id="rs-widget" token="634fe4abda434300224a1a04" locale="<?php if(empty($langURL)){ echo 'tr';} else { echo $langURL;} ?>"></rc-widget>