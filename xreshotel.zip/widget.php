    <!-- tatilbudur  -->
    <div class="iletisim-m home" id="tbphone">
        <ul>
            <li><a href="tel:+902427450986" class="changePhone">0242 745 09 86</a></li>
            <li><a href="reservation" target="_blank">Online Rezervasyon</a></li>
        </ul>
    </div>
   
<div id="rezervasyon-widget"></div>    
<rc-widget id="rs-widget" locale="en"></rc-widget>
    <div id=phoneRes></div>